
Importante:
Temporariamente foi desativada a opcao de LibCurl e OpenSSL.
As rotinas existem em hbNFeAssina e hbNFeSefaz, mas nao estao habilitadas.

Componentes:

Capicom

Componente usado pra comunica��o SOAP e pra assinatura.
Pode ser baixada livremente da Microsoft.

A opcao alternativa e usar LibCurl e OpenSSL.


msxml5.dll e msxml5r.dll

Todas as versoes do msxml fazem parte do Windows, exceto esta versao 5.0.
Somente esta versao pode fazer assinatura digital.
Foi lancada apenas como componente do Office.

A opcao alternativa e usar LibCurl e OpenSSL


Como registrar os componentes no Windows 32 bits:

Copiar as DLLs pra \windows\system32 e executar regsvr32 existente nessa pasta
regsvr32 capicom.dll
regsvr32 msxml5.dll
regsvr32 msxml5r.dll


Como registrar os componentes no Windows 64 bits:

Copiar as DLLs pra \windows\SysWOW64 e executar regsv32 existente nessa pasta (NAO USE o regsvr32 de \windows\system32)
Mesmos comandos de 32 bits, so altera a pasta



Porque cada metodo tem oSefaz, se hbnfe ja tem isso?

Em hbnfe - usado como configuracao geral

Supondo que voce trabalhe com uma empresa em Sao Paulo, a UF default sera SP no oSefaz da hbnfe.
Mas ao consultar uma NFe de outra UF, ou cadastro de outra UF, tem que ser usada a UF correspondente.
Desta forma a UF padrao permanece correta.

Se quiser trabalhar diretamente com XMLs, sem arquivos intermediarios, pode usar somente SefazClass()


Explicacao dos componentes:

hbNFeSefaz  - Classe de comunicacao com a Sefaz. Alguns XMLs simples sao gerados nesta classe.
              Atualizar sempre que a Sefaz criar um novo webservice.
hbNfeAssina - classe de assinatura. Ajustar sempre que a Sefaz criar um novo documento ou nova versao.
